package br.com.alura.agenda.ui.activity;

public interface ConstantesActivities {

    String TITULO_APPBAR_EDITA_ALUNO = "Edita Aluno";
    String TITULO_APPBAR_NOVO_ALUNO = "Lista de alunos";
    String CHAVE_ALUNO = "aluno";
}
